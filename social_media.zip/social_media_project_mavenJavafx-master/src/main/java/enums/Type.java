package enums;

public enum Type {
    SIMPLE,BUSINESS;
    Type()
    {}
}
