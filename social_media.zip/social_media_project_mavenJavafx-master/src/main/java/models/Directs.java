package models;

public class Directs {
}
