package models;



public class BusinessUser  {


}