package controller;

public abstract class Controller {

}
