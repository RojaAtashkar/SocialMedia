package models;


public class SimpleUser {


}