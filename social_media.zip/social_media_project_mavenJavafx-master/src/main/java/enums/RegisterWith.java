package enums;

public enum RegisterWith {
    EMAIL,
    PHONE_NUMBER;
    RegisterWith(){
    }
}
