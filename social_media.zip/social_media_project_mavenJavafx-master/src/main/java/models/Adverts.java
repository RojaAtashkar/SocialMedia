package models;

public class Adverts {
}
