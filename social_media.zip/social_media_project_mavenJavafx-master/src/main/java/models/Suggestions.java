package models;

public class Suggestions {
}
