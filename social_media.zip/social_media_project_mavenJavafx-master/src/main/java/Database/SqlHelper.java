package Database;

public class SqlHelper {

}
